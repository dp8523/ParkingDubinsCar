population_size = 200
num_optimization_parameters = 10
num_high_resolution_parameters = 100
duration = 10
chromosome_length = 7
mutation_rate = 0.005
infeasibility_constant = 200
